import java.net.*;
import java.io.*;
import java.util.*;

//For Server.
//First run Server.java rather than WaitingRoom.java.

public class Server {
	ServerSocket ss;
	Vector<Guest> v = new Vector<Guest>();
	HashMap<String, Vector> map = new HashMap<String, Vector>();
	
	public Server() {
		try {
			ss = new ServerSocket(3441);
			while(true) {
				Socket s = ss.accept();
				Guest g = new Guest(s, this);
				addGuest(g);
				g.setDaemon(true);
				g.start();   
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	// Add user in waiting room
	public void addGuest(Guest g) {
		v.add(g);
	}
	// Remove user in waiting room
	public void removeGuest(Guest g) {
		v.remove(g);
	}
	// Add Chat room
	public void addRoom(String roomtitle) {
		Vector<Guest> rv = new Vector<Guest>();
		map.put(roomtitle, rv);
	}
	// Remove Chat room
	public void removeRoom(String roomtitle) {
		map.remove(roomtitle);
	}
	// Add user in chat room
	public void addRoomGuest(Guest g) {
		Vector<Guest> rv = map.get(g.roomtitle);
		rv.add(g);
	}
	// Remove user in chat room
	public void removeRoomGuest(Guest g) {
		Vector<Guest> rv = map.get(g.roomtitle);
		rv.remove(g);
		if(rv.size() == 0) {
			removeRoom(g.roomtitle);
			broadcast("removeroom/");
		}
	}
	// Alert user in waiting room
	public void broadcast(String message) {
		for(Guest g : v) {
			g.sendMessage(message);
		}
	}
	// Alert user in chat room
	public void broadcastRoom(String roomtitle, String message) {
		if(map.get(roomtitle) != null) {
			Vector<Guest> rv = map.get(roomtitle);
			for(Guest g : rv) {
				g.sendMessage(message);
			}
		}
	}
	
	// Room list
	public void broadcastRoomList() {
		String roomlist = "roomlist/";
		Set<String> set = map.keySet();
		for(String roomtitle : set) {
			String name = roomtitle;
			roomlist += roomtitle + "/";
			for(int i = 0; i < map.size(); i++) {
				Vector<Guest> rv = map.get(name);
				roomlist += rv.size() + "/";
			}
		}
		broadcast(roomlist);
	}
	
	// Waiting room user list
	public void broadcastGuestList() {
		String guestlist = "guestlist/";
		for(Guest g : v) {
			guestlist += g.id + "/";
		}
		broadcast(guestlist);
	}
	
	// Chatting room user list
	public void broadcastRoomGuestList(String roomtitle) {
		String roomguestlist = "roomguestlist/";
		if(map.get(roomtitle) != null) {
			Vector<Guest> rv = map.get(roomtitle);
			if(rv.size() > 0) {
				for(Guest g : rv) {
					roomguestlist += g.id + "/";
				}
				broadcastRoom(roomtitle, roomguestlist);
			}
		}
	}
	// Main
	public static void main(String args[]) {
		Server server = new Server();
	}
}