import java.net.*;
import java.util.*;
import java.io.*;

//For Guest's Status.
//Just program's function, No exist main.
//Please run Server.java and WaitingRoom.java.

public class Guest extends Thread {
	Socket s;
	Server server;
	BufferedReader br;
	BufferedWriter bw;
	String id, roomtitle, say;
	
	public Guest(Socket s, Server server) {
		this.s = s;
		this.server = server;
		try {
			br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			bw = new BufferedWriter(new OutputStreamWriter(s.getOutputStream()));
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
 
	public void run() {
		String line="";
		try {
			while ((line = br.readLine()) != null) {
				System.out.println(line);
				String[] arr = CheckMessage(line.substring(line.indexOf("/") + 1));
				
				// Enter the Waiting room
				if (line.startsWith("in/")) {
					id = arr[0];
					server.broadcastRoomList();
					server.broadcastGuestList();
				} 
				// Exit the Waiting room
				else if (line.startsWith("out/")) {
					id = arr[0];
					server.removeGuest(this);
					server.broadcastRoomList();
					server.broadcastGuestList();
					flush();     
				}
				// Make a Chat room
				else if (line.startsWith("makeroom/")) {
					roomtitle = arr[0];
					id = arr[1];
					server.addRoom(roomtitle);
					server.addRoomGuest(this);
					server.removeGuest(this);
					server.broadcastRoomList();
					server.broadcastGuestList();
					server.broadcastRoomGuestList(roomtitle);
				}
				// Remove a Chat room
				else if (line.startsWith("removeroom/")) {
					server.broadcastRoomList();
					server.broadcastGuestList();    
				}
				// Enter the Chat room
				else if (line.startsWith("enterroom/")) {
					roomtitle = arr[0];
					id = arr[1];
					server.addRoomGuest(this);
					server.removeGuest(this);
					server.broadcastRoomList();
					server.broadcastGuestList();
					server.broadcastRoomGuestList(roomtitle);
					server.broadcastRoom(roomtitle, line);
				}
				// Exit the Chat room
				else if (line.startsWith("exitroom/")) {
					roomtitle=arr[0];
					id = arr[1];
					server.addGuest(this);
					server.removeRoomGuest(this);
					server.broadcastRoomList();
					server.broadcastGuestList();
					server.broadcastRoomGuestList(roomtitle);
					server.broadcastRoom(roomtitle, line);
				}
				// Talking with Client
				else if (line.startsWith("say/")) {
					roomtitle = arr[0];
					id = arr[1];
					say = arr[2];
					server.broadcastRoom(roomtitle, line);
				}
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	// Send a Message
	public void sendMessage(String message) {
		try {
			bw.write(message+"\n");
			bw.flush();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	// Check a Message
	public String[] CheckMessage(String message) {
		StringTokenizer st = new StringTokenizer(message, "/");
		String[] arr = new String[st.countTokens()];
		for(int i = 0; st.hasMoreTokens(); i++) {
			arr[i] = st.nextToken();
		}
		return arr;
	}
	
	// All Resource Flush
	public void flush() {
		try {
			br.close();
			bw.close();
			s.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
}