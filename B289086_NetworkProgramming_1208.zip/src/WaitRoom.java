import java.net.*;
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

// For Client.
// Second run WaitRoom.java after Server.java.

public class WaitRoom extends JFrame implements ActionListener {
	JButton b;
	JList li1, li2;
	JScrollPane sp1, sp2;
	JTextField tf;

	Socket socket;
	String ip;
	BufferedReader br;
	BufferedWriter bw;
	ChatRoom cr;
	String id, roomtitle;
	
	public WaitRoom(String ip, String id) {
		super(" " + id + " 's Waiting room");
		this.id = id;
		JPanel pan1 = new JPanel();
		JPanel pan2 = new JPanel();
		pan1.setLayout(new BorderLayout());
		pan2.setLayout(new BorderLayout());
		li1 = new JList();
		
		// Button click for Enter to Waiting room
		li1.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent me) {
				if(me.getButton() == 1) {
					if((String)li1.getSelectedValue() != null) {
						String selectroom = (String)li1.getSelectedValue();
						selectroom = selectroom.substring(0, selectroom.indexOf("/"));
						WaitRoom.this.selectRoom(selectroom);
					}
				}
			}
		});
		
		li2 = new JList();
		tf = new JTextField(30);
		tf.addActionListener(this);
		b = new JButton("Make Room");
		b.addActionListener(this);
		pan1.add(li1, "Center");
		pan1.add(li2, "East");
		pan2.add(tf, "Center");
		pan2.add(b, "East");
		Container container = getContentPane();
		container.add(pan1, "Center");
		container.add(pan2, "South");
		
		try {
			socket = new Socket(ip, 3441);
			br = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			bw = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
		} catch (UnknownHostException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		
		sendMessage("in/" + id);
		// Button click for Exit Waiting room
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				sendMessage("out/" + WaitRoom.this.id);
				flush();
				System.exit(1);
			}
		});
	}
	
	// Event
	public void actionPerformed(ActionEvent ae) {
		// Make a Chat room
		cr = new ChatRoom(this, tf.getText());
		roomtitle = tf.getText();
		sendMessage("makeroom/" + tf.getText() + "/" + id);
		setVisible(false);
		tf.setText("");
	}
	
	// Select a room in list
	public void selectRoom(String selectroom) {
		// Enter the Chat room
		cr = new ChatRoom(this, selectroom);
		roomtitle = selectroom;
		sendMessage("enterroom/" + roomtitle + "/" + id);
		setVisible(false);  
	}
	
	// Send a Message
	public void sendMessage(String message) {
		try {
			bw.write(message + "\n");
			bw.flush();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	// Receive a Message
	public void readmessage() {
		String line="";
		try {
			while ((line = br.readLine()) != null) {
				String[] arr = checkmessage(line.substring(line.indexOf("/") + 1));
				
				// Show room list
				if (line.startsWith("roomlist/")) {
					li1.removeAll();
					String[] room = new String[arr.length];
					for(int i = 0, j = 1; i < arr.length; i += 2, j += 2){
						room[i] = arr[i] + "/" + arr[j];
					}
					li1.setListData(room);
				}
				// Show Waiting users
				else if (line.startsWith("guestlist/")) {
					li2.removeAll();
					li2.setListData(arr);
				}
				// Show Chatting users
				else if (line.startsWith("roomguestlist/")) {
					cr.li.removeAll();
					cr.li.setListData(arr);
				}
				// Alert enter in room for users
				else if(line.startsWith("enterroom/")) {
					cr.ta.append("[" + arr[1] + "] IN..." + "\n");
				}
				// Alert exit at room for users
				else if(line.startsWith("exitroom/")) {
					cr.ta.append("[" + arr[1] + "] OUT..." + "\n");
				}
				// Show chatting contents
				else if(line.startsWith("say/")) {
					cr.ta.append("[" + arr[1] + "] : " + arr[2] + "\n");
				}
				//
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	
	// Check a message
	public String[] checkmessage(String message) {
		StringTokenizer st = new StringTokenizer(message, "/");
		String[] arr = new String[st.countTokens()];
		
		for(int i = 0; st.hasMoreTokens(); i++) {
			arr[i] = st.nextToken();
		}
		return arr;
	}
	
	// All Resource Flush
	public void flush() {
		try {
			br.close();
			bw.close();
			socket.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}
	// Main
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Please write your nickname. : "); 
		String nickname = sc.nextLine();
		System.out.print("Please write ip, too. : ");
		String ip = sc.nextLine();		
		WaitRoom rl = new WaitRoom(ip, nickname);
		rl.setBounds(200, 200, 400, 300);
		rl.setVisible(true);
		rl.readmessage();
	}
}