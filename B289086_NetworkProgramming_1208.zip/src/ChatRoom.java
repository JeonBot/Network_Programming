import java.net.*;
import java.util.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

//For Chat room.
//Just GUI, No exist main.
//Please run Server.java and WaitingRoom.java.

public class ChatRoom extends JFrame implements ActionListener {
	JButton b;
	JFrame f;
	JList li;
	JMenuItem mi; 
	JPanel pan1, pan2;
	JPopupMenu pm;
	JScrollPane sp1, sp2;
	JTextArea ta;
	JTextField tf;

	BufferedReader br;
	BufferedWriter bw;
	WaitRoom rl;
	String roomtitle;
	
	public ChatRoom(WaitRoom rl, String roomtitle) {
		super(" Roomtitle : " + roomtitle);
		this.rl = rl;
		this.roomtitle = roomtitle;
		pan1 = new JPanel();
		pan2 = new JPanel();
		pan1.setLayout(new BorderLayout());
		pan2.setLayout(new BorderLayout());
		ta = new JTextArea(15, 30);
		li = new JList();
		pm = new JPopupMenu();
		tf = new JTextField();
		tf.addActionListener(this);
		b = new JButton("Exit Room");
		b.addActionListener(this);
		sp1 = new JScrollPane(ta);
		sp2 = new JScrollPane(li);
		pan1.add(sp1, "Center");
		pan1.add(sp2, "East");
		pan2.add(b, "East");
		pan2.add(tf, "Center");
		
		Container container = getContentPane();
		container.add(pan1, "Center");
		container.add(pan2, "South");
		// Exit a Chat room
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				ChatRoom.this.rl.sendMessage("exitroom/" + ChatRoom.this.rl.roomtitle + "/" + ChatRoom.this.rl.id);
				setVisible(false);
				ChatRoom.this.rl.setVisible(true);
			}
		});
		
		// Home Position
		pack();
		setBounds(400, 400, 600, 500);
		setVisible(true);
	}
	
	// Event
	public void actionPerformed(ActionEvent ae) {
		// Chatting
		if(ae.getSource() == tf) {
			rl.sendMessage("say/" + rl.roomtitle + "/" + rl.id + "/" + tf.getText());
			tf.setText("");   
		}
		// Exit a Chat room
		else if(ae.getSource() == b) {
			rl.sendMessage("exitroom/" + rl.roomtitle + "/" + rl.id);
			setVisible(false);
			rl.setVisible(true);
		}
	}
}